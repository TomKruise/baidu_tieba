from urllib import request
from urllib import parse
from urllib.request import urlopen

import random
import time


def tieba(url, begin, end):
	"""
		pn= 0, 50, 100, 150, ......
		pn = (page - 1) * 50
	"""
	for page in range(begin, end + 1):

		second = random.randint(1,3)

		time.sleep(second)

		pn = (page-1) * 50

		filename = "Page_" + str(page) + ".html"

		fullurl = url + "&ie=utf-8&pn=" + str(pn)

		html = loadPage(fullurl, filename)

		writeFile(html, filename)


def loadPage(url, filename):

	print("Downloading %s"%filename)

	headers = {"User-Agent" : "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0"}

	req = request.Request(url, headers = headers)

	response = urlopen(req)

	return response.read()


def writeFile(text, filename):

	print("Writing %s"%filename)

	with open(filename, "w") as f:
		f.write(str(text))

	print("*"*50)
	print ("Write is done!")


if __name__ == "__main__":
	"""
		http://tieba.baidu.com/f?kw=python3&ie=utf-8&pn=250
	"""

	kw = input("Type the name: ")

	beginPage = int(input("Type the start page number: "))

	endPage = int(input("Type the end page number: "))

	url = "http://tieba.baidu.com/f?"

	key = parse.urlencode({"kw" : kw})

	url = url + key

	tieba(url, beginPage, endPage)